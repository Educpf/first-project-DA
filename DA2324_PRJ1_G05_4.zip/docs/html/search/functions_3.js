var searchData=
[
  ['getcode_0',['getCode',['../class_element.html#a1e835fe6819e2b2ab4d80a0c38c5ffce',1,'Element']]],
  ['getcopy_1',['getCopy',['../class_graph.html#afcc2f4bbcf9efd648e88ff79df0966c5',1,'Graph']]],
  ['getdemand_2',['getDemand',['../class_city.html#a49d90f5913832295150b401643f341e7',1,'City']]],
  ['getid_3',['getId',['../class_element.html#a59a83e75bf6068ba4cdfff754d8b78d1',1,'Element']]],
  ['getmaxdelivery_4',['getMaxDelivery',['../class_reservoir.html#a59a17dd56e7ed41778007f0b5e64e69d',1,'Reservoir']]],
  ['getmunicipality_5',['getMunicipality',['../class_reservoir.html#a05b3ae3fe93212c1e5608cd5aeee1231',1,'Reservoir']]],
  ['getname_6',['getName',['../class_city.html#a79ba022573d8174291b5dac268ee5ec0',1,'City::getName()'],['../class_reservoir.html#aa73308e734ce198e2217ce00205763ba',1,'Reservoir::getName()']]],
  ['getpopulation_7',['getPopulation',['../class_city.html#a23be6779c2ba1f5ee0f303b9a160216d',1,'City']]]
];
