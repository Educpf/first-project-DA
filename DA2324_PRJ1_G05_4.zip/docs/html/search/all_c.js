var searchData=
[
  ['_7emanager_0',['~Manager',['../class_manager.html#a322cad25d7007438b3a043ad02253d29',1,'Manager']]]
];
