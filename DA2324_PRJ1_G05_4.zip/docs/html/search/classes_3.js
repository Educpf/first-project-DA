var searchData=
[
  ['manager_0',['Manager',['../class_manager.html',1,'']]]
];
