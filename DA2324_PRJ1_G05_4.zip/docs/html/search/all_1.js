var searchData=
[
  ['calculatemaxflow_0',['CalculateMaxFlow',['../class_manager.html#add8808216cee9d5537d8e5870207b92c',1,'Manager']]],
  ['citiesindeficit_1',['citiesInDeficit',['../class_manager.html#a822fcf6a0ff2c69cbba13558ddab9c74',1,'Manager']]],
  ['city_2',['City',['../class_city.html',1,'City'],['../class_city.html#af6f58f060aa349ac358eb757ee37c048',1,'City::City()']]]
];
